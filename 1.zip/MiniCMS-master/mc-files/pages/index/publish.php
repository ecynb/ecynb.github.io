<?php
$mc_posts=array (
  'aboutus' => 
  array (
    'id' => 'xf32ss',
    'state' => 'publish',
    'title' => '测试页面1',
    'date' => '2013-03-21',
    'time' => '08:47:36',
    'can_comment' => '1',
    'path' => 'aboutus',
  ),
)
?>