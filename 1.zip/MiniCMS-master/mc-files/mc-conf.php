<?php
$mc_config = array (
  'site_link' => 'http://127.0.0.1/minicms/',
  'site_name' => '我的网站',
  'site_desc' => '有一个MiniCMS网站',
  'user_name' => 'admin',
  'user_pass' => 'da3f1pY3OCuq9G8oA8SjomHxmNxPOefi8V319VleRf1Aiw',
  'user_nick' => '某人',
  'comment_code' => '123',
)
?>