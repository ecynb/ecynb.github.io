    </div>
  </div>
  <div id="footer" class="row"><div id="footer_box"><a href="<?php echo $mc_config['site_link']; ?>">&copy;<?php echo htmlspecialchars($mc_config['site_name']); ?></a></div></div>
</body>
</html>
