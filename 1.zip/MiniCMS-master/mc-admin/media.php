<?php require_once 'head.php'; ?>
<div class="admin_page_name">站点设置</div>
<div>
    正在开发！
</div>
<?php require 'foot.php' ?>;